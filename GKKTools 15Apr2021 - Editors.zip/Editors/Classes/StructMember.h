* StructMember.h
* For internal use by the StructMember class in the Struct component

#DEFINE ccMemoryAddress	1
#DEFINE ccMemorySize		2